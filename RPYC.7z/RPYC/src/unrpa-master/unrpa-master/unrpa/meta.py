name = "unrpa"
version = "2.3.0"
description = (
    "Extract files from the RPA archive format (from the Ren'Py Visual Novel Engine)."
)
