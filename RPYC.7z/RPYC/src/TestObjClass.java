import java.util.List;


public class TestObjClass {

	List<TestObjClassChild> sss;
	
	public List<TestObjClassChild> getSss() {
		return sss;
	}

	public void setSss(List<TestObjClassChild> sss) {
		this.sss = sss;
	}

	public static class TestObjClassChild<T>
	{
		T cost,errCode,errMsg;

		public T getCost() {
			return cost;
		}

		public void setCost(T cost) {
			this.cost = cost;
		}

		public T getErrCode() {
			return errCode;
		}

		public void setErrCode(T errCode) {
			this.errCode = errCode;
		}

		public T getErrMsg() {
			return errMsg;
		}

		public void setErrMsg(T errMsg) {
			this.errMsg = errMsg;
		}
	}
	
	
	
}
