import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.SwingUtilities;


public class UnRpyc {

	private  Map<String, String> map = new HashMap<String, String>();
	private  List<String> list = new ArrayList();
	String line;
	boolean isSuccess=true;
	
	public void converRPYC(String unRpycPath,String path,MainFrame mainFrame) {
		File file = new File(path);

		findRpyc(file);

		Runtime runtime = Runtime.getRuntime();
		System.err.println("�ļ��У�" + map.size());
	
		for (String string : map.values()) {

			try {
				StringBuilder sbCMD = new StringBuilder();
				sbCMD.append("cmd.exe /c ");
				sbCMD.append(unRpycPath).append(" -c ").append(string);
				System.err.println(sbCMD.toString());
				Process process = runtime.exec(sbCMD.toString());

				InputStream is = process.getInputStream();
				BufferedReader br = new BufferedReader(
						new InputStreamReader(is));

				while ((line = br.readLine()) != null) {
					System.err.println(line);
					SwingUtilities.invokeLater(new Runnable() {

						@Override
						public void run() {
							mainFrame.appendText(line);
						}
					});
				}
				is.close();
				process.waitFor();
			} catch (IOException e) {
				isSuccess=false;
				e.printStackTrace();
				SwingUtilities.invokeLater(new Runnable() {

					@Override
					public void run() {
						if(isSuccess)
						{
							mainFrame.appendRedText(e.getMessage());
						}
					}
				});
				
			} catch (InterruptedException e) {
				isSuccess=false;
				e.printStackTrace();
				SwingUtilities.invokeLater(new Runnable() {

					@Override
					public void run() {
						if(isSuccess)
						{
							mainFrame.appendRedText(e.getMessage());
						}
					}
				});
			}
		}
		
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				if(isSuccess)
				{
					mainFrame.appendRedText("RPYC�������\n");
					deleteRpycAndRPA(new File(path));
					mainFrame.appendRedText("RPYC�ļ���ɾ��\n");
				}
			}
		});

	}
	
	
	private  void findRpyc(File file) {
		File[] files = file.listFiles();
		for (File mfile : files) {
			if (mfile.isDirectory()) {
				findRpyc(mfile);
			} else {

				if (mfile.isFile() && mfile.exists()) {
					String name = mfile.getPath();
					if (name.substring(name.length() - 4).toLowerCase()
							.equals("rpyc")) {
						map.put(mfile.getParent(), mfile.getParent());
						list.add(name);
					}
					if (name.substring(name.length() - 3).toLowerCase()
							.equals("rpa")) {
						map.put(mfile.getParent(), mfile.getParent());
						list.add(name);
					}
				}
			}
		}
	}

	private  void deleteRpycAndRPA(File file) {
		File[] files = file.listFiles();
		for (File mfile : files) {
			if (mfile.isDirectory()) {
				deleteRpycAndRPA(mfile);
			} else {

				if (mfile.isFile() && mfile.exists()) {
					String name = mfile.getPath();
					if (name.substring(name.length() - 4).toLowerCase()
							.equals("rpyc")) {
						mfile.delete();
					}
					if (name.substring(name.length() - 3).toLowerCase()
							.equals("rpa")) {
						mfile.delete();
					}
				}
			}
		}
	}
}
