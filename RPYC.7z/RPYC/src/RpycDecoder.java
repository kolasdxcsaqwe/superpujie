import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.SwingUtilities;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.html.HTMLDocument;

public class RpycDecoder {

	private static String unRpycPath = "";
	private static String unRpyaPath = "";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// +"unrpyc-master/unrpyc-master/unrpyc.pyc"

		unRpycPath = System.getProperties().getProperty("user.dir")
				+ "\\bin\\unrpyc-master\\unrpyc.pyc";
		unRpyaPath = System.getProperties().getProperty("user.dir")
				+ "\\bin\\unrpa-master\\unrpa-master\\unrpa";
		System.err.println(System.getProperties().getProperty("user.dir"));
		System.err.println(unRpycPath);
		System.err.println(unRpyaPath);

		new MainFrame(unRpycPath);
	}

	

	

	
}
