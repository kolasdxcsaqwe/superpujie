import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.html.HTMLDocument;


public class MainFrame {


	private static JTextPane textPane;
	private static JScrollPane scrollPane;
	
	MainFrame(String unRpycPath)
	{
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLayout(null);
		frame.setBounds(300, 300, 800, 500);

		JLabel labelpath = new JLabel();
		labelpath.setText("����ת��·��(���ɴ��пո�)");
		labelpath.setBounds(50, 20, 200, 30);
		labelpath.setBackground(Color.red);
		frame.add(labelpath);

		JLabel label = new JLabel();
		label.setText("����̨���");
		label.setBounds(50, 70, 150, 30);
		frame.add(label);

		textPane = new JTextPane();
		textPane.setContentType("text/html");
		textPane.setEditable(false);
		textPane.setBackground(Color.WHITE);
		textPane.setBounds(50, 110, 700, 300);
		scrollPane = new JScrollPane(textPane);
		scrollPane.setBounds(50, 110, 700, 300);
		frame.add(scrollPane);

		JTextField textField = new JTextField();
		textField.setText("");
		textField.setVisible(true);
		textField.setBounds(260, 20, 150, 30);
		textField.setBackground(Color.white);
		textField.requestFocus();
		frame.add(textField);

		JButton button = new JButton();
		button.setText("ת��RPYC��PRA");
		button.setBounds(420, 20, 150, 30);
		button.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub

				if (textField.getText().length() == 0) {
					appendText("����д��ַ");
					return;
				}
				File file = new File(textField.getText());

				if (file == null || !file.exists() || file.isFile()) {
					appendText("��ַ���󣡣���");
					return;
				}
				textPane.setText("");
				scrollPane.getViewport().setViewPosition(new Point(0, 0));

				new Thread() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						super.run();
						new UnRpyc().converRPYC(unRpycPath, textField.getText(),MainFrame.this);
					}

				}.start();

			}
		});
		frame.add(button);

		frame.setVisible(true);
	}
	
	public  void appendText(String text) {
		try {
			textPane.getDocument().insertString(
					textPane.getDocument().getLength(), text+"\n", null);
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		scrollPane.getViewport().setViewPosition(
				new Point(0, Integer.MAX_VALUE));
	}
	
	public  void appendRedText(String text)
	{
		try {
			StringBuilder sb=new StringBuilder();
			sb.append("<font color='red'>").append(text).append("</font>");
			HTMLDocument htmlDocument=(HTMLDocument) textPane.getStyledDocument();
			htmlDocument.insertAfterEnd(htmlDocument.getCharacterElement(htmlDocument.getLength()), sb.toString());
		} catch (BadLocationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		scrollPane.getViewport().setViewPosition(
				new Point(0, Integer.MAX_VALUE));
	}
}
