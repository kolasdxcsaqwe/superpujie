import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import com.google.gson.Gson;


public class Test {

	static AtomicInteger integer=new AtomicInteger();
	static int iii=0;
	public static String kk="{\"sss\":[\n" +
            "    {\n" +
            "        \"cost\":910,\n" +
            "        \"errCode\":{\n" +
            "\n" +
            "        },\n" +
            "        \"errMsg\":\"�����ɹ�\"\n" +
            "    },\n" +
            "    {\n" +
            "        \"cost\":{\n" +
            "\n" +
            "        },\n" +
            "        \"errCode\":\"0000\",\n" +
            "        \"errMsg\":[\n" +
            "\n" +
            "        ]\n" +
            "    },\n" +
            "    {\n" +
            "        \"cost\":\"\",\n" +
            "        \"errCode\":\"0000\",\n" +
            "        \"errMsg\":\"�����ɹ�\"\n" +
            "    }\n" +
            "]}";
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1655308800112
		//1655395200432
//		System.err.println(System.currentTimeMillis());
//		Calendar calendar=Calendar.getInstance();
//		calendar.set(Calendar.HOUR, 24);
//		calendar.set(Calendar.MINUTE, 0);
//		calendar.set(Calendar.SECOND, 0);
//		System.err.print(calendar.getTimeInMillis());
		
		CountDownLatch countDownLatch=new CountDownLatch(1);
	
		try {
			new Thread(){
				public void run() {
					try {
						System.err.println("111");
						sleep(2000);
						System.err.println("rrrrr");
						countDownLatch.countDown();
						System.err.println("2222");
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						System.err.println("3333");
					}
				};
			}.start();
			
			countDownLatch.await(47000, TimeUnit.MILLISECONDS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.err.println("4444");
		}
		finally
		{
			System.err.println("6666");
		}
		System.err.println("5555");
	}
	
	public static class MyThread extends Thread
	{
		int i;

		public MyThread(int i2) {
			// TODO Auto-generated constructor stub
			i=i2;
		}

		public int getI() {
			return i;
		}

		public void setI(int i) {
			this.i = i;
		}
		
	}

}
