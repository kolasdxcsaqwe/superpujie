<a name="1.1.0"></a>
# [1.1.0](https://github.com/zimv/websocket-heartbeat-js/compare/v1.0.13...v1.1.0) (2022-03-10)


### Features

* add protocols param & pingMsg type: any ([5ff4297](https://github.com/zimv/websocket-heartbeat-js/commit/5ff4297))



<a name="1.0.13"></a>
## [1.0.13](https://github.com/zimv/websocket-heartbeat-js/compare/v1.0.12...v1.0.13) (2021-03-18)


### Bug Fixes

* window error in nodejs ([e547ca7](https://github.com/zimv/websocket-heartbeat-js/commit/e547ca7))



<a name="1.0.9"></a>
## 1.0.9 (2020-02-22)



<a name="1.0.8"></a>
## 1.0.8 (2019-04-09)

### Features

* add a limit to the times of reconnection ([75c60af](https://github.com/zimv/websocket-heartbeat-js/commit/75c60af))



<a name="1.0.7"></a>
## 1.0.7 (2018-10-25)


### Bug Fixes

*  after closed, send message bug ([d9f4850](https://github.com/zimv/websocket-heartbeat-js/commit/d9f4850))


<a name="1.0.6"></a>
## 1.0.6 (2018-10-18)


### Bug Fixes

* manual close need to over heartbeat ([07b8dd7](https://github.com/zimv/websocket-heartbeat-js/commit/07b8dd7))


<a name="1.0.5"></a>
## 1.0.5 release (2018-10-15)


### docs update


<a name="1.0.4"></a>
## 1.0.4 (2018-10-11)


### Features

* demo ([3070b96](https://github.com/zimv/websocket-heartbeat-js/commit/3070b96))
* webpack & lib ([e1514e7](https://github.com/zimv/websocket-heartbeat-js/commit/e1514e7))



